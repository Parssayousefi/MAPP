function Meta (meta)
  meta.old = nil
  meta.new = "new"
  meta.bool = (meta.bool == false)
  return meta
end
