package.path = package.path .. ';lua/?.lua'
require 'script-name'
