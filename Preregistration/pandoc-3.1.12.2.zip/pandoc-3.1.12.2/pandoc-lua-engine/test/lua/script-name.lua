function Para (_)
  return pandoc.Para{pandoc.Str(PANDOC_SCRIPT_FILE)}
end
