# pandoc-lua-engine

This package provides a Lua pandoc scripting engine based. It
allows to write filters, custom readers, and custom writers in
Lua.

