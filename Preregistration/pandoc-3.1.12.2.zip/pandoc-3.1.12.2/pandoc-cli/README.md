# pandoc-cli

This package provides the command-line document-conversion program `pandoc`.
There is not much to this package; all of the work is done by
the libraries `pandoc` and `pandoc-server`.

## License

© 2006-2022 John MacFarlane (jgm@berkeley.edu). Released under the
[GPL](https://www.gnu.org/licenses/old-licenses/gpl-2.0.html "GNU General Public License"),
version 2 or greater. This software carries no warranty of any kind.
(See COPYRIGHT for full copyright and warranty notices.)
